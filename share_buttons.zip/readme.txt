=== Share Buttons for WordPress ===
Contributors: Loskutnikov Artem (artlosk)
Tags: social, network, jquery, share buttons, social buttons, twitter, facebook, vkontakte, odnoklassniki, mail.ru
Requires at least: 2.8
Tested up to: 3.0
Stable tag: 1.0

The Share buttons, it is plugin for social networks. The plugin supports 5 social networking.

== Description ==

The Share buttons, it is plugin for social networks. The plugin supports 5 social networking. 
There are Vkontakte, Odnoklassniki.ru, Mail.ru russian social buttons and there are Facebook, Twitter english social buttons. 
This plugin is written using AJAX and Jquery. The plugin supports 2 languages: English and Russian

[FAQ](http://artlosk.com/2010/10/social-share-buttons/), but on russian language

== Languages ==

* English - default
* Russina(ru_RU)

== Installation ==

1. Unzip the file
2. Upload it to wp-content/plugins
3. Activate it from the plugins section
4. Go to the FTP "wp-content/plugins/share_buttons/upload/ and change chmod folder "/UPLOADS/" to 0777. Your logo will store in this folder.


== Screenshots ==
1. Screenshot 1: Box for upload your logo
2. Screenshot 2: Box for position share buttons
3. Screenshot 3: Settings for Vkontakte buttons
4. Screenshot 4: Settings for Odnoklassniki button
5. Screenshot 5: Settings for Mail.ru button
6. Screenshot 6: Settings for Facebook buttons
7. Screenshot 7: Settings for Twitter button


== Changelog ==

= 1.0 =

Plugin release.